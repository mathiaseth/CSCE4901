export { default } from '../profile';
